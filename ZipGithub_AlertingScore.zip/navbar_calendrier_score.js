
// javascript for tab navigation
const btnLeft = document.querySelector(".fa-angle-left");
const btnRight = document.querySelector(".fa-angle-right");
const tabMenu = document.querySelector(".tab-menu");

tabMenu.scrollLeft=420;

let scrollLeftValue = Math.ceil(tabMenu.scrollLeft);
console.log(scrollLeftValue);

// const IconVisibility = () => {
//     let scrollLeftValue = Math.ceil(tabMenu.scrollLeft);
//     console.log(scrollLeftValue);
//     let scrollableWidth = tabMenu.scrollWidth - tabMenu.scrollLeft;
//     console.log("2.",scrollableWidth);

//     btnLeft.style.display = scrollLeftValue < 350 ? "block" : "none";
//     btnRight.style.display = scrollableWidth > 350 ? "block" : "none";
// }

btnRight.addEventListener("click", ()=>{
    tabMenu.scrollLeft+=150;
    //IconVisibility();
    //setTimeout(() => IconVisibility(),50);
})

btnLeft.addEventListener("click", ()=>{
    tabMenu.scrollLeft-=150;
    // IconVisibility();
    //setTimeout(() => IconVisibility(),50);
})



// window.onload = function(){
//     btnRight.style.display = tabMenu.scrollWidth > tabMenu.clientWidth || 
//                              tabMenu.scrollWidth >= window.innerWidth ? "block" : "none";
//     btnLeft.style.display = tabMenu.scrollWidth >= window.innerWidth ? "" : "none";
// }

// window.onresize = function(){
//     btnRight.style.display = tabMenu.scrollWidth > tabMenu.clientWidth || 
//                              tabMenu.scrollWidth >= window.innerWidth ? "block" : "none";
//     btnLeft.style.display = tabMenu.scrollWidth >= window.innerWidth ? "" : "none";

//     let scrollLeftValue = Math.round(tabMenu.scrollLeft);

//     btnLeft.style.display = scrollLeftValue > 0 ? "block" : "none";
// }


// Javascript to make the tab navigation draggable
let activeDrag = false;

tabMenu.addEventListener("mousemove", (drag) => {
    if(!activeDrag) return;
    tabMenu.scrollLeft -= drag.movementX;
    IconVisibility();
    tabMenu.classList.add("dragging");
});

document.addEventListener("mouseup", () => {
    activeDrag = false;
    tabMenu.classList.remove("dragging");
});

tabMenu.addEventListener("mousedown", () => {
    activeDrag = true;
})


// Javascript to view tb contents on click tab button
const tabs = document.querySelectorAll(".tab");
const tabBtns = document.querySelectorAll(".tab-btn");

const tab_Nav = function(tabBtnClick) {
    tabBtns.forEach((tabBtn) => {
        tabBtn.classList.remove("active");
    });

    tabs.forEach((tab) =>{
        tab.classList.remove("active");
    })

    tabBtns[tabBtnClick].classList.add("active");
    tabs[tabBtnClick].classList.add("active");
}

tabBtns.forEach((tabBtn, i) =>{
    tabBtn.addEventListener("click", () => {
        tab_Nav(i);
    })
})



